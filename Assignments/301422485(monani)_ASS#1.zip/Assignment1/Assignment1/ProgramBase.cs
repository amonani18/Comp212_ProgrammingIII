﻿namespace Assignment1
{
    internal class ProgramBase
    {
    }
}